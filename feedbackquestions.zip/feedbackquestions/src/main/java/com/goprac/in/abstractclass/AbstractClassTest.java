package com.goprac.in.abstractclass;

abstract public class AbstractClassTest {
	public void print() {
		System.out.println("Hi !! I am in Abstract class");
	}
	 public abstract void getMe();

}

class AbstractClassTestImpl extends AbstractClassTest{
	public void get() {
		System.out.println("Hi!! I am in impl class");
	}
	 public  void getMe() {
		 
	 }
}
