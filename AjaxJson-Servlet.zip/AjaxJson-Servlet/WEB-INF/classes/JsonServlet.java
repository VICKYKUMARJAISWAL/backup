

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JsonServlet
 */
public class JsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public JsonServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String topic=request.getParameter("topicName");
		String  data=getJSONData(topic);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println(data);
		
		out.close();
		
	}
	public  String   getJSONData(String  topic)
	{
		StringBuffer  buffer=null;
		if(topic.equalsIgnoreCase("Java"))
		{
			buffer=new  StringBuffer();
			buffer.append("{\"topic\":{\"name\":\"Java\",\"tutorial\":[{\"name\":\"Java complete reference\"},{\"name\":\"Thinking in java\"}]}}");
		}
		else if(topic.equalsIgnoreCase("Design pattern"))
		{
			buffer=new StringBuffer();
			buffer.append("{\"topic\":{\"name\":\"DesignPatterns\",\"tutorial\":[{\"name\":\"Factory\"},{\"name\":\"Singleton\"}]}}");
			
		}
		else
		{
			buffer=new  StringBuffer();
			buffer.append("{\"topic\":{\"name\":\"topic\",\"tutorial\":[{\"name\":\"NotFound\"}]}}");
		}
		
		return buffer.toString();
	}

}
