package com.saurabh.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.saurabh.hibernate.dao.StudentDAO;
import com.saurabh.hibernate.dao.StudentDAOFactory;
import com.saurabh.hibernate.model.Student;


public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	//read   the parameter
		int id=Integer.parseInt(request.getParameter("sid").trim());
		
		//get the object of DAO class
		
		StudentDAO dao=StudentDAOFactory.getInstance();
		//call the DAO class  method
		List <Student>list=dao.readStudent(id);
		//read object from the List
		Student student=(Student)list.get(0);
		PrintWriter out=response.getWriter();
		if(student!=null)
		{
			out.println("SID:"+student.getStudentId());
			out.println("SNAME:"+student.getStudentName());
			out.println("MARKS:"+student.getMarks());
		}
		else
		{
			out.println("Sorry,the given id is doesn't exist in database");
		}
		out.println("<a href=index.html>Home</a>");
		out.close();
		
	}

}
