package com.saurabh.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.saurabh.hibernate.dao.StudentDAO;
import com.saurabh.hibernate.dao.StudentDAOFactory;


public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//read the parameters
		int id=Integer.parseInt(request.getParameter("sid").trim());
        int marks=Integer.parseInt(request.getParameter("marks").trim());
        //create the object of  dao class
        StudentDAO dao=StudentDAOFactory.getInstance();
      //read the id from the database
       
        dao.updateStudent(id, marks);
        PrintWriter out=response.getWriter();
        out.println("<h2>the  object is successfully updated</h2>");
        out.println("<a href=index.html>Home</a>");
        out.close();
      
        
	}

}
