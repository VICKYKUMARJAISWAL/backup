package com.saurabh.hibernate.model;

public class Student {
	//properties of the Student class
	private Integer studentId;
	private String studentName;
	private Integer marks;
	//default constructor
	public Student(){}
	//generate setter and getter method for each property
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Integer getMarks() {
		return marks;
	}
	public void setMarks(Integer marks) {
		this.marks = marks;
	}
	
	

}
