package com.saurabh.hibernate.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.saurabh.hibernate.model.Student;
import com.saurabh.hibernate.util.HibernateUtils;

public class StudentDAOImpl implements StudentDAO {

	public boolean insertStudent(int id, String name, int marks)
	{
		//create SessionFactory object here 
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Student student=new Student();
		student.setStudentId(id);
		student.setStudentName(name);
		student.setMarks(marks);
		Transaction tx=session.beginTransaction();
		try
		{
			session.persist(student);
			tx.commit();
			return true;
		}
		catch(Exception e)
		{
		   tx.rollback();
		   return false;
		}
		finally
		{
		  session.close();	
		}
		
	}

	public List<Student> readStudent(int id)
	{
	//create SessionFacotry objetct
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Student student=(Student)session.get(Student.class,id);
		session.close();
		ArrayList<Student> arraylist=new ArrayList<Student>();
		arraylist.add(student);
		return arraylist;
	}
	
	
	public void updateStudent(int id,int marks)
	{
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Student student=(Student)session.get(Student.class,id);
		student.setMarks(marks);
		Transaction tx=session.beginTransaction();
		try
		{
			session.update(student);
			tx.commit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
		session.close();
		}
       		
	}
			
	public void deleteStudent(int id)
	{
		//create the object of  SessionFactory
		SessionFactory factory=HibernateUtils.getSessionFactory();
		//create Session object
		Session session=factory.openSession();
		Student student=(Student)session.get(Student.class,id);
		Transaction tx=session.beginTransaction();
		session.delete(student);
		tx.commit();
		
	}
	
}

