package com.saurabh.hibernate.dao;

import java.util.List;

import com.saurabh.hibernate.model.Student;

public interface StudentDAO {
	boolean insertStudent(int id,String name,int marks);
	List<Student> readStudent(int id);
	void updateStudent(int id,int marks);
	void deleteStudent(int id);

}
