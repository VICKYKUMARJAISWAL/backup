package com.sathya.hibernate.dao;

public interface StudentDAO {
	void insertStudent(String name,int marks);
	void readStudent(int id);

}
