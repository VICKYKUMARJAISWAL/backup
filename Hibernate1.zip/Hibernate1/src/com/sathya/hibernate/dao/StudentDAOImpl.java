package com.sathya.hibernate.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.sathya.hibernate.model.Student;
import com.sathya.hibernate.util.HibernateUtils;

public class StudentDAOImpl implements StudentDAO {

	@Override
	public void insertStudent(String name, int marks) {
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Student student=new Student();
		student.setStudentName(name);
		student.setMarks(marks);
		Transaction tx=session.beginTransaction();
		session.save(student);
		tx.commit();
		session.close();
		System.out.println("Row Inserted");
	}

	@Override
	public void readStudent(int id) {
	SessionFactory factory=HibernateUtils.getSessionFactory();
	Session session=factory.openSession();
	Student student=(Student)session.get(Student.class,id);
	System.out.println("Name="+student.getStudentName());
	System.out.println("Marks="+student.getMarks());
	session.close();

	}

}
