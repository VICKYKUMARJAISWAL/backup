package com.sathya.hibernate.dao;

public class StudentDAOFactory {
	public static StudentDAO getInsatance()
	{
		return new StudentDAOImpl();
	}
	}

