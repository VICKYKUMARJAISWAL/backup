import com.sathya.hibernate.dao.StudentDAO;
import com.sathya.hibernate.dao.StudentDAOFactory;


public class Main {

	
	public static void main(String[] args) {
		
		StudentDAO dao=StudentDAOFactory.getInsatance();
		dao.insertStudent("A",500);
		System.out.println("========================");
		dao.readStudent(1);
			

	}

}
