package com.saurabh.hibernate.dao;

public interface OneToManyDAO {
	void saveCustomerWithItems();
	void additionalObject();
	void deleteAppropriateObject();

}

