package com.saurabh.hibernate.dao;

public class OneToManyDAOFactory {
	public static OneToManyDAO getInstance()
	{
		return new OneToManyDAOImpl();
	}

}
