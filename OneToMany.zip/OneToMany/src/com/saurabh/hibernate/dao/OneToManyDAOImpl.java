package com.saurabh.hibernate.dao;


import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.saurabh.hibernate.model.Customer;
import com.saurabh.hibernate.model.Item;
import com.saurabh.hibernate.util.HibernateUtils;


public class OneToManyDAOImpl implements OneToManyDAO {
	public void saveCustomerWithItems()
	{
		Customer customer=new  Customer();
		customer.setCustomerId(90);
		customer.setCustomerName("surbhi");
		customer.setCustomerAddress("Lucknow");
		//prepare the Item objects
		Item item1=new Item();
		item1.setItemId(21);
		item1.setItemName("gulavjamun");
		item1.setItemPrice(400);
		//create 2nd object of Item
		Item item2=new Item();
		item2.setItemId(22);
		item2.setItemName("rasgulla");
		item2.setItemPrice(800);
		//create  a  collection type  to set Item objects
		Set items=new HashSet();
		items.add(item1);
		items.add(item2);
		//set  this items object to customer object
		customer.setItems(items);
		//create a SessionFactory object  to  get session
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(customer);
		tx.commit();
		session.close();
		
		}
	public void additionalObject()
	{
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Item item3=new Item();
		item3.setItemId(60);
		item3.setItemName("laddu");
		item3.setItemPrice(1000);
		//read the cutomer objetc
		Customer customer=(Customer)session.load(Customer.class, 90);
		Set items=customer.getItems();
		items.add(item3);
		customer.setItems(items);
		Transaction tx=session.beginTransaction();
		session.save(customer);
		tx.commit();
		session.close();
	}
	
	public void deleteAppropriateObject()
	{
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		//read the customer object
		Customer customer=(Customer)session.load(Customer.class, 90);
		//read the Item object
		Item item=(Item)session.load(Item.class, 22);
		Set items=customer.getItems();
		Transaction tx=session.beginTransaction();
		items.remove(item);
		tx.commit();
		session.close();
		
		
		
	}
	
	
	

}
