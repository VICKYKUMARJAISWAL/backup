import com.saurabh.hibernate.dao.OneToManyDAO;
import com.saurabh.hibernate.dao.OneToManyDAOFactory;


public class Main {
	public static void main(String args[])
	{
		OneToManyDAO dao=OneToManyDAOFactory.getInstance();
		//dao.saveCustomerWithItems();
		//dao.additionalObject();
	   dao.deleteAppropriateObject();
	}

}
