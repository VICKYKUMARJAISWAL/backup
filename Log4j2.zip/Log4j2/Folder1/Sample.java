import  org.apache.logging.log4j.Logger;
import  org.apache.logging.log4j.LogManager;
class  Sample
{
	static Logger  logger = LogManager.getLogger(Sample.class);
	public static void main(String[] args) 
	{
		logger.trace("Trace message");
		logger.debug("Debug message");
		logger.info("info message");
		logger.warn("warn message");
		logger.error("error message");
		logger.fatal("fatal message");
	}
}
