package com.saurabh.hibernate.dao;

public class StudentDAOFactory {
	public static StudentDAO getInstance()
	{
		return new  StudentDAOImpl();
	}

}
