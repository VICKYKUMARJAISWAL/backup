package com.saurabh.hibernate.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.saurabh.hibernate.model.Student;
import com.saurabh.hibernate.util.HibernateUtils;

public class StudentDAOImpl implements StudentDAO {

	@Override
	public void insertStudent(String name, int marks) {
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
		Student student=new Student();
		student.setStudentName(name);
		student.setMarks(marks);
		Transaction tx=session.beginTransaction();
		session.persist(student);
		System.out.println("Student object is  inserted into databse");
		tx.commit();
		session.close();
	}

	@Override
	public void readStudent(int id) {
	  //session factory object is created in  my second method
		SessionFactory factory=HibernateUtils.getSessionFactory();
		Session session=factory.openSession();
        Student	student=(Student)session.get(Student.class, id);
        System.out.println("Student Name:"+student.getStudentName());
        System.out.println("==============");
        System.out.println("Student Marks:"+student.getMarks());
		session.close();		
	  }

}
