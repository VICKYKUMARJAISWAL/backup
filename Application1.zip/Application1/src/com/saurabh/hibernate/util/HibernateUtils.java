package com.saurabh.hibernate.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtils {
	//my  SessionFactory doesn't have object initially
	private static SessionFactory factory=null;
	// to  make our SessionFactory object  is singleton  
	//I  have made my utillity class constructor is private
	private HibernateUtils(){}
	//create a  factory object
	public static SessionFactory getSessionFactory()
	{
		if(factory==null)
		{
			factory=new Configuration().configure("com/saurabh/hibernate/config/hibernate.cfg.xml").buildSessionFactory();
		}
		return  factory;
	}
	

}
