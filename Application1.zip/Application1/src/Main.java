import com.saurabh.hibernate.dao.StudentDAO;
import com.saurabh.hibernate.dao.StudentDAOFactory;


public class Main {
	public static void main(String[]args)
	{
		StudentDAO dao=StudentDAOFactory.getInstance();
		dao.insertStudent("Saurabh", 90);
		dao.readStudent(1);
		
	}

}
